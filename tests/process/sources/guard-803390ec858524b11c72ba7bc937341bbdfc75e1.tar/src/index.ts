import "./loaded-code.ts";
import { Type } from "@mariozechner/pi-ai";
import type {
	ExtensionAPI,
	ExtensionCommandContext,
	ExtensionContext,
} from "@mariozechner/pi-coding-agent";
import {
	AutoReviewController,
	type AutoReviewDependencies,
} from "./auto-review.ts";
import { handleGuardCommand, parseGuardArgs } from "./commands.ts";
import {
	type LoadedConfigResult,
	loadConfig,
	loadProjectConfig,
} from "./config.ts";
import { evaluateToolCall } from "./evaluator.ts";
import { buildPolicySnapshot, filterPolicySnapshot } from "./policy.ts";
import {
	ConfigurationCapture,
	ProtectionSnapshot,
} from "./protection-snapshot.ts";
import { RequiredDecisionController } from "./required-decision.ts";
import {
	DEFAULT_REVIEWER_CONFIG,
	type ReviewerConfig,
} from "./reviewer-config.ts";
import {
	formatReviewerModelStatus,
	pickReviewerModel,
	resolveReviewerModel,
	setReviewerSessionModel,
} from "./reviewer-model.ts";
import type { GuardContext, ToolCallInput } from "./types.ts";

export {
	captureReviewerConversation,
	createReviewerRequest,
	parseReviewerJudgment,
	reviewGuardRequest,
} from "./reviewer.ts";
export { loadReviewerConfigFromSettings } from "./reviewer-config.ts";
export {
	readSessionModelOverride,
	resolveReviewerModel,
	setReviewerSessionModel,
} from "./reviewer-model.ts";
export { parseGuardArgs };

interface LoadedStartupConfig extends LoadedConfigResult {
	envRules?: GuardContext["staticPolicy"]["envRules"];
	reviewerError?: string;
	reviewer?: ReviewerConfig;
}

export interface GuardBootstrap {
	loaded?: LoadedStartupConfig;
	projectResult?: LoadedConfigResult | null;
	startupCwd?: string;
	autoReview?: AutoReviewDependencies;
}

function jsonToolResult(value: unknown) {
	return {
		content: [{ type: "text" as const, text: JSON.stringify(value, null, 2) }],
		details: value,
	};
}

function registerGuardCheck(pi: ExtensionAPI, context: GuardContext): void {
	pi.registerTool({
		name: "guard_check",
		label: "Guard check",
		description:
			"Read the current pi-guard policy snapshot or evaluate a proposed tool call without executing it, opening approval UI, or changing rules.",
		promptSnippet: "Inspect pi-guard rules or dry-run a proposed tool call",
		promptGuidelines: [
			"Use guard_check before proposing a command when the applicable pi-guard rule is unclear.",
			"A guard_check allow result describes pi-guard only; another sandbox or extension may still block execution.",
		],
		parameters: Type.Object({
			mode: Type.Union([Type.Literal("check"), Type.Literal("rules")]),
			tool: Type.Optional(Type.String()),
			input: Type.Optional(Type.Record(Type.String(), Type.Unknown())),
			commandPrefix: Type.Optional(Type.String()),
		}),
		async execute(_toolCallId, params, _signal, _onUpdate, ctx) {
			const snapshot = buildPolicySnapshot(context);
			if (params.mode === "rules") {
				return jsonToolResult(
					filterPolicySnapshot(snapshot, {
						...(params.tool ? { tool: params.tool } : {}),
						...(params.commandPrefix
							? { commandPrefix: params.commandPrefix }
							: {}),
					}),
				);
			}
			if (!params.tool || !params.input) {
				return jsonToolResult({
					error: 'mode "check" requires both tool and input',
					policyVersion: snapshot.policyVersion,
				});
			}
			return jsonToolResult(
				evaluateToolCall(snapshot, params.tool, params.input, ctx.cwd).result,
			);
		},
	});
}

export function registerGuard(
	pi: ExtensionAPI,
	bootstrap?: GuardBootstrap,
): void {
	const options = bootstrap ?? {};
	const configurationCapture = new ConfigurationCapture();
	const loaded = options.loaded ?? loadConfig(configurationCapture.observe);
	const startupCwd = options.startupCwd ?? process.cwd();
	const projectResult =
		options.projectResult !== undefined
			? options.projectResult
			: loadProjectConfig(startupCwd, configurationCapture.observe);
	const warnings = [
		loaded.warning,
		loaded.reviewerError,
		projectResult?.warning,
	].filter(Boolean);
	if (warnings.length > 0) console.warn(`[pi-guard] ${warnings.join("; ")}`);
	const reviewerConfig = structuredClone(
		loaded.reviewer ?? DEFAULT_REVIEWER_CONFIG,
	);

	const context: GuardContext = {
		config: loaded.config,
		staticPolicy: {
			userRules: loaded.config.rules,
			projectRules: projectResult?.config.rules ?? {},
			envRules: loaded.envRules,
			projectConfigPresent: projectResult !== null,
		},
		activeProfile: undefined,
		sessionRules: {},
		exactSessionGrants: [],
	};
	const autoReview = new AutoReviewController(
		pi,
		context,
		reviewerConfig,
		options.autoReview,
	);
	const requiredDecision = new RequiredDecisionController(pi);
	const protection = new ProtectionSnapshot(
		pi,
		context,
		reviewerConfig,
		startupCwd,
		configurationCapture,
		bootstrap !== undefined || warnings.length > 0,
		() =>
			autoReview.hasProtectionRuntimeState() ||
			requiredDecision.hasProtectionRuntimeState(),
	);
	let sessionGeneration = 0;
	let sessionActive = true;

	function resetSessionState(): void {
		autoReview.sessionChanged();
		requiredDecision.sessionChanged();
		sessionGeneration++;
		sessionActive = true;
		context.activeProfile = undefined;
		context.sessionRules = {};
		context.exactSessionGrants = [];
		delete context.sessionEnabled;
	}

	function reviewerStatus(ctx: ExtensionContext): string {
		return `Reviewer: ${reviewerConfig.mode} · ${formatReviewerModelStatus(resolveReviewerModel(reviewerConfig, ctx))}`;
	}

	function updateGuardStatus(ctx: ExtensionContext): void {
		if (!ctx.hasUI) return;
		const snapshot = buildPolicySnapshot(context);
		const modelStatus = reviewerStatus(ctx);
		if (!snapshot.guardEnabled) {
			ctx.ui.setStatus("guard", `⚠️ Guard: off · ${modelStatus}`);
			return;
		}
		const bashRules =
			typeof snapshot.effectiveRules === "object"
				? snapshot.effectiveRules.bash
				: snapshot.effectiveRules;
		const count =
			typeof bashRules === "object"
				? Object.keys(bashRules).length
				: bashRules
					? 1
					: 0;
		ctx.ui.setStatus(
			"guard",
			ctx.ui.theme.fg(
				"accent",
				`🛡️ Guard: ${count} bash rules · ${modelStatus}`,
			),
		);
	}

	function notifyUnavailableReviewerPicker(ctx: ExtensionCommandContext): void {
		if (!ctx.hasUI)
			ctx.ui.notify(
				"Reviewer model picker is unavailable here. Use /guard model main or /guard model <provider>/<model-id>.",
				"warning",
			);
	}

	function applyReviewerModelChoice(
		choice: string,
		ctx: ExtensionCommandContext,
	): void {
		const result = setReviewerSessionModel(pi, ctx, choice);
		ctx.ui.notify(
			result.ok
				? `Reviewer model selected for this session. ${reviewerStatus(ctx)}`
				: result.reason,
			result.ok ? "info" : "warning",
		);
		if (result.ok) {
			protection.observe();
			updateGuardStatus(ctx);
		}
	}

	async function runReviewerModelCommand(
		target: string,
		ctx: ExtensionCommandContext,
	): Promise<void> {
		if (target === "status") {
			ctx.ui.notify(reviewerStatus(ctx), "info");
			return;
		}
		const generation = sessionGeneration;
		const choice = target || (await pickReviewerModel(ctx, reviewerConfig));
		if (!sessionActive || generation !== sessionGeneration) return;
		if (!choice) {
			if (!target) notifyUnavailableReviewerPicker(ctx);
			return;
		}
		applyReviewerModelChoice(choice, ctx);
	}

	async function runGuardCommand(
		args: string,
		ctx: ExtensionCommandContext,
	): Promise<void> {
		const { action, target } = parseGuardArgs(args);
		if (action === "model") return runReviewerModelCommand(target, ctx);
		if (action === "approve") {
			const result = autoReview.approve(target, ctx);
			ctx.ui.notify(result.message, result.ok ? "info" : "warning");
			return;
		}
		if (action === "answer") {
			const result = requiredDecision.answer(target, ctx);
			ctx.ui.notify(result.message, result.ok ? "info" : "warning");
			return;
		}
		const result = handleGuardCommand(action, target, context);
		protection.observe();
		const modelStatus = reviewerStatus(ctx);
		ctx.ui.notify(
			action === "list" || action === ""
				? `${result.message}\n\n${modelStatus}`
				: result.message,
			result.type,
		);
		updateGuardStatus(ctx);
	}

	for (const [shortcut, subcommand] of Object.entries(
		context.config.shortcuts ?? {},
	)) {
		if (!subcommand) continue;
		pi.registerCommand(shortcut, {
			description: `pi-guard shortcut: ${subcommand}`,
			handler: async (_args, ctx) => runGuardCommand(subcommand, ctx),
		});
	}

	pi.registerCommand("guard", {
		description: "Manage pi-guard security settings",
		handler: async (args, ctx) => runGuardCommand(args, ctx),
	});
	pi.registerCommand("guard-toggle", {
		description: "Toggle pi-guard on/off for this session",
		handler: async (_args, ctx) => {
			const result = handleGuardCommand("toggle", undefined, context);
			protection.observe();
			ctx.ui.notify(result.message, result.type);
			updateGuardStatus(ctx);
		},
	});

	registerGuardCheck(pi, context);
	requiredDecision.registerTool();
	pi.on("session_start", async (_event, ctx) => {
		protection.beginSession();
		try {
			resetSessionState();
			requiredDecision.restore(ctx);
			updateGuardStatus(ctx);
			protection.started(ctx);
		} catch (error) {
			protection.failed();
			throw error;
		}
	});
	pi.on("session_before_switch", async () => {
		protection.unsupportedLifecycle();
		autoReview.abortPending();
		requiredDecision.abortDialog();
	});
	pi.on("session_before_fork", async () => {
		protection.unsupportedLifecycle();
		autoReview.abortPending();
		requiredDecision.abortDialog();
	});
	pi.on("session_before_tree", async () => {
		protection.unsupportedLifecycle();
		autoReview.abortPending();
		requiredDecision.abortDialog();
		sessionGeneration++;
	});
	pi.on("session_switch", async (_event, ctx) => {
		protection.unsupportedLifecycle();
		resetSessionState();
		requiredDecision.restore(ctx);
		updateGuardStatus(ctx);
	});
	pi.on("session_fork", async (_event, ctx) => {
		protection.unsupportedLifecycle();
		resetSessionState();
		requiredDecision.restore(ctx);
		updateGuardStatus(ctx);
	});
	pi.on("session_shutdown", async () => {
		protection.endSession();
		resetSessionState();
		sessionActive = false;
	});
	pi.on("session_tree", async (_event, ctx) => {
		protection.unsupportedLifecycle();
		autoReview.branchChanged();
		requiredDecision.restore(ctx);
		sessionGeneration++;
		updateGuardStatus(ctx);
	});
	pi.on("model_select", async (_event, ctx) => {
		protection.observe();
		updateGuardStatus(ctx);
	});
	pi.on("input", async (event, ctx) => {
		const blocked = requiredDecision.input(event.text, event.source, ctx);
		if (blocked) return blocked;
		autoReview.newUserInput();
	});
	pi.on("message_end", async (event) => {
		if (event.message.role === "user")
			requiredDecision.userMessage(event.message.content);
	});
	pi.on("message_start", async (event) => {
		if (event.message.role === "assistant")
			requiredDecision.assistantMessageStarted();
	});
	pi.on("tool_result", async (event) => {
		requiredDecision.toolResult(event.toolName, event.toolCallId);
		const result = autoReview.toolResult(event);
		autoReview.newUserInput();
		return result;
	});
	pi.on("tool_execution_end", async (event) =>
		autoReview.toolExecutionEnd(event),
	);
	pi.on("tool_call", async (event, ctx) => {
		if (event.toolName !== "guard_check") protection.beginOperation();
		try {
			const decisionResult = requiredDecision.preflight(event, ctx);
			if (decisionResult || event.toolName === "guard_require_decision")
				return decisionResult;
			if (event.toolName === "guard_check") return;
			if (!sessionActive)
				return {
					block: true,
					reason: "[Blocked by pi-guard: Session is no longer active]",
				};
			const generation = sessionGeneration;
			const sessionId = ctx.sessionManager.getSessionId();
			const isCurrentSession = () =>
				sessionActive &&
				sessionGeneration === generation &&
				ctx.sessionManager.getSessionId() === sessionId;
			const snapshot = buildPolicySnapshot(context);
			const evaluated = evaluateToolCall(
				snapshot,
				event.toolName,
				event.input as ToolCallInput,
				ctx.cwd,
			);
			const result = await autoReview.handle(
				event,
				ctx,
				snapshot,
				evaluated,
				isCurrentSession,
			);
			return isCurrentSession()
				? result
				: {
						block: true,
						reason: "[Blocked by pi-guard: Session changed during approval]",
					};
		} finally {
			if (event.toolName !== "guard_check") protection.endOperation();
		}
	});
}

export default registerGuard;
